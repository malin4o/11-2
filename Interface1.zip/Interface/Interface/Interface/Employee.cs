﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interface
{
    abstract class Employee
    {
        //има execute, success Rate, counterTasks, k 
        protected bool execute = true; // връща true, ако задачата е изпълнена успешно
        protected int counterTasks;
       
        protected double successRate;
        protected int k;

        public string firstname;
        public string lastname;
        public string typeOfWork;
        public string text;
        protected string tasks;

        public string txt
        {
            get;
            set;
        }
        public void Print()

        {
            Console.WriteLine("{6} : {3} - {4} {5}", typeOfWork,k, firstname, lastname);
        }
    }
 }


