﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interface
{
    class Manager : Employee
    {

        private int workercounter;  //за броя на подчинените

        public override string  PrintStatus()
        {
            return base.PrintStatus() + workercounter;
        }


    }
}
