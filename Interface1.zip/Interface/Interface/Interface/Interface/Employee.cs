﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interface
{
    abstract class Employee
    {
        public string tеxt=Console.ReadLine(); //0
        public string firstname; //1
        public string lastname; //2
        public string workertype; //3
        int counterTasks;//4
        double successRate;  //5
      /*6*/  bool execute; //връща true ,ако задачата е успешна 

       



      public  virtual string PrintStatus()
        {
            return $"{workertype} : {firstname}, {lastname}, {successRate}";
        
        }


    }
}


