﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interface
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] array = new int[5];
            string[] stringArray = new string[6];


            bool showMenu = true;
            while (showMenu)
            {
                showMenu = MainMenu();
            }
        }
        private static bool MainMenu()
        {
            Console.Clear();
            Console.WriteLine("Choose an option:");
            Console.WriteLine("1) Name of task");
            Console.WriteLine("2) Number of employees");
            Console.WriteLine("3) Name and job of employee");
            Console.WriteLine("4) Exit");
            Console.Write("\r\nSelect an option: ");

            switch (Console.ReadLine())
            {
                case "1":
                    Nameoftask();
                    return true;
                case "2":
                    Numberofemployees();
                    return true;
                case "3":
                    Nameandjobofemployee();
                    return true;
                case "4":
                    return false;
                default:
                    return true;
            }
        }

        private static void Nameoftask()
        {
            Console.Clear();
            Console.WriteLine("Name of task");

        }
        private static void Numberofemployees()
        {
            Console.Clear();
            Console.WriteLine("Number of employees");

        }
        private static void Nameandjobofemployee()
        {
            Console.Clear();
            Console.WriteLine("Name and job of employee");

        }
    }
    }
}
