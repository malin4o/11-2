﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interface
{
    class Worker:Employee 
    {
        public Worker()
        {
            base.name = name;
            base.counterTask = counterTask;
            base.uspevaemost = uspevaemost;
            base.managerOwner = managerOwner;
            base.k = k;
        }

        public override int Execute()
        {
            counterTask++;
            if (counterTask % k == 0)
            {
                uspevaemost /= counterTask;
                return Convert.ToInt32(uspevaemost * 10);
            }
            else
            {
                return Convert.ToInt32(uspevaemost * 10);
            }
        }

        public override void SuccessRate()
        {
            Console.WriteLine("Uspevaemostta na {0} e {1}.", name, uspevaemost);
        }
    }
}
