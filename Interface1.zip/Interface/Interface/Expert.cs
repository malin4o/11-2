﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interface
{
    class Expert:Employee
    {
        public Expert()
        {
            base.name = name;
            base.counterTask = counterTask;
            base.uspevaemost = uspevaemost;
            base.managerOwner = managerOwner;
        }
        public override int Execute()
        {
            Console.WriteLine("Zadachata e uspeshna");
            return counterTask++;
        }
        public override void SuccessRate()
        {
            throw new NotImplementedException();
        }
    }
}
