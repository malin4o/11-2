﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interface
{
    abstract class Employee
    {
        protected string name;
        protected int counterTask;
        protected int k;
        protected double uspevaemost;
        protected Manager managerOwner;

        public string Name
        {
            get;
            set;
        }

        public abstract int Execute();
        public abstract void SuccessRate();
    }
 }


