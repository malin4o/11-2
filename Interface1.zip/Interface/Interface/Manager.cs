﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interface
{
    class Manager : Employee
    {
        //Add, delete, printStatus
        List<string> name = new List<string>();
        public void Add()
        {
            for (int i = 0; i < name.Count; i++)
            {
                text= Console.ReadLine();
                name.Add(text);
            }
        }
        public void Delete()
        {
           
            for (int i = 0; i < name.Count; i++)
            {
                txt = Console.ReadLine();
                name.Remove(txt);
            }

        }

        public void PrintStatus()
        { 
          for(int i=0; i<name.Count; i++)
          { 
            Console.WriteLine(" {4} {5} : {2}");
          }

        }
       
    }
}
