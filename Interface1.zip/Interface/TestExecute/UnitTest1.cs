using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace TestExecute
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            Worker a = new Worker("Georgi", 12, 11);
            Assert.AreEqual(4, a.Execute(), "PRogramata ima greshka");
        }
    }
}
